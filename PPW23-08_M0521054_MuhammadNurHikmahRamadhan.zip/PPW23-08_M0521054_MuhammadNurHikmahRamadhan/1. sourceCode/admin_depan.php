<?php
include("header.php");
?>
<h1>Halaman Depan</h1>
Selamat datang di halaman depan
<?php
include("footer.php");
?>